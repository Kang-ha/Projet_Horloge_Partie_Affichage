# Arduino Library For ADXL345

[![Build Status](https://travis-ci.org/jakalada/Arduino-ADXL345.svg?branch=master)](https://travis-ci.org/jakalada/Arduino-ADXL345)

ADXL345 (A acceleration sensor) library for Arduino.

## Install

[Download the latest library release.](https://github.com/jakalada/Arduino-ADXL345/releases/latest) Or [Use the Library Manager.](https://www.arduino.cc/en/Guide/Libraries#toc3)


## Examples

[Please see example code.](./examples)

